#include <iostream>

#include <fstream>
#include <string>
#include <utility>
#include <vector>
#include <algorithm>

using namespace std;

pair<int, int> start;
pair<int, int> goal;

vector<vector<int>> map;

struct path {
	int row = 0;
	int col = 0;
	vector<pair<int, int>> prev;
	bool finish = false;
	bool dead = false;
};

vector<path> solutions;


vector<vector<int>> getMap() {
	vector<vector<int>> result;

	ifstream input("Day12test.txt");

	int row = 0;
	int col = 0;

	while (input) {
		string line;
		getline(input, line);

		if (line.length() == 0)
			break;

		vector<int> maprow;
		col = 0;
		for (auto c : line) {
			if (c == 'S') {
				c = 'a';
				start = { row, col };
			}
			else if (c == 'E') {
				c = 'z';
				goal = { row, col };
			}

			maprow.push_back(c - 97);

			col++;
		}
		
		result.push_back(maprow);

		row++;
	}

	input.close();

	return result;
}

bool hasPrev(const path& pos, int row, int col) {
	for (const auto& p : pos.prev)
		if (p.first == row && p.second == col)
			return true;

	return false;
}

vector<path> getBranches(const path& pos) {
	int curr = map[pos.row][pos.col];

	path eval;

	vector<path> results;

	for (int c = pos.col - 1; c <= pos.col + 1; c++) {
		for (int r = pos.row - 1; r <= pos.row + 1; r++) {
			if (r >= 0 && r < map.size() // valid row
				&& c > 0 && c < map[0].size() // valid col
				&& !(r == pos.row && c == pos.col) // not current pos (to eval)
				&& !(r == start.first && c == start.second) // not start pos
				&& ( r == pos.row || c == pos.col) // not diagonal
				&& !hasPrev(pos, r, c) // not loop
				&& map[r][c] - 1 <= curr) { // at most one higher
				results.push_back({ r, c, pos.prev });
			}
		}
	}

	for (auto& r : results) {
		if (r.row == goal.first && r.col == goal.second)
			r.finish = true;

		r.prev.push_back({ pos.row, pos.col });
	}

	return results;
}

int getMinSolution(const vector<path>& solution) {
	int minSteps = 10000;
	for (auto& s : solution)
	{
		if (s.finish && s.prev.size() < minSteps)
			minSteps = s.prev.size();
	}
	return minSteps;
}

int main() {
	cout << " AoC 2022 Day12" << endl;

	map = getMap();

	solutions.push_back({ start.first, start.second });

	while (true) {
		vector<path> newsolutions;
		for (auto& s : solutions) {
			auto branches = getBranches(s);
			newsolutions.insert(newsolutions.end(), branches.begin(), branches.end());
		}

		//solutions.insert(solutions.end(), newsolutions.begin(), newsolutions.end());
		solutions = newsolutions;

		int minSteps = getMinSolution(solutions);

		solutions.erase(remove_if(solutions.begin(), solutions.end(), [minSteps](const path& el) { return el.prev.size() > minSteps; }), solutions.end());

		bool allFinish = true;
		for (auto& s : solutions)
			allFinish = allFinish && s.finish;

		if (allFinish)
			break;

	}

	cout << "Minsteps: " << getMinSolution(solutions) << endl;

	return 0;
}
